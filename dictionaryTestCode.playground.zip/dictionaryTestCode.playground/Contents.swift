import UIKit

/* var dicArray: [String] = []
var word = "Cat"
if dicArray.isEmpty {
    dicArray.insert(word, at: 0)
    }
else {
    dicArray.append(word)
}
print(dicArray) */

func dictioanry(engWord englishWord: String, ruWord russianWord: String) -> [String: String] {
    var englishArr: [String] = ["door", "forest"]
    var russianArr: [String] = ["дверь", "лес"]
    var associationArr = zip(englishArr, russianArr)
    var vocabulary = Dictionary(uniqueKeysWithValues: associationArr)
    if englishArr.isEmpty && russianArr.isEmpty {
        englishArr.insert(englishWord, at: 0)
        russianArr.insert(russianWord, at: 0)
        associationArr = zip(englishArr, russianArr)
        vocabulary = Dictionary(uniqueKeysWithValues: associationArr)
    }
    else {
        englishArr.append(englishWord)
        russianArr.append(russianWord)
        associationArr = zip(englishArr, russianArr)
        vocabulary = Dictionary(uniqueKeysWithValues: associationArr)
    }
    return vocabulary
    
}
dictioanry(engWord: "cat", ruWord: "кошка")


